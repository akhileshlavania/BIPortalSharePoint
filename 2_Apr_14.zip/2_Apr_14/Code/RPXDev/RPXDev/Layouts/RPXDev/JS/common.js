
menuJson = topNavMenu;

var menuContainer = $("<ul></ul>");
var mnMenus = [];
for (x in menuJson) {
    var firstChildFlag = 1;
    if (menuJson.hasOwnProperty(x)) {
        var subMenuContainer = $("<li></li>");
        for (y in menuJson[x]) {

            if (menuJson[x].hasOwnProperty(y)) {

                if (typeof (menuJson[x][y]) != 'object') {

                    if (y == "name") {
                        $(subMenuContainer).html(menuJson[x][y]);
                        var upperMenu = $("<li></li>");
                        var upperMenuLink = $("<a></a>");
                        $(upperMenuLink).html(menuJson[x][y]);
                        $(upperMenuLink).attr('href', '#');
                        $(upperMenu).append(upperMenuLink);
                    }

                    else if (y == "child-id") {
                        var childId = menuJson[x][y];
                        $(subMenuContainer).attr('data', menuJson[x][y]);
                        $('#menu-rpx-menu').append(upperMenu);
                    }
                    else if (y == "data-top") {
                        $(upperMenu).attr('id', menuJson[x][y]);
                        $(subMenuContainer).attr('' + y + '', menuJson[x][y]);
                    }
                    else if (y == 'id') {
                        $(subMenuContainer).attr('' + y + '', menuJson[x][y]);
                        $(upperMenu).attr('data', menuJson[x][y]);
                        mnMenus.push(menuJson[x][y]);
                    }
                    else
                        $(upperMenu).attr('data', menuJson[x][y]);


                }

                else {

                    if (firstChildFlag) {
                        var container = $("<ul></ul>");
                        $(container).attr('id', childId);
                        firstChildFlag = 0;
                    }

                    for (z in menuJson[x][y]) {


                        if (menuJson[x][y].hasOwnProperty(z)) {
                            var subContainer = $("<li></li>");

                            for (w in menuJson[x][y][z]) {
                                var firstSubChildFlag = 1;
                                if (menuJson[x][y][z].hasOwnProperty(w)) {
                                    if (w !== 'url') {

                                        // attributes of this child
                                        if (typeof (menuJson[x][y][z][w]) == 'string' && menuJson[x][y][z][w]) {

                                            if (w == "name")
                                                $(subContainer).html(menuJson[x][y][z][w]);
                                            else {
                                                if (w == "child-id") {
                                                    var subChildId = menuJson[x][y][z][w];
                                                    $(subContainer).attr('data', menuJson[x][y][z][w]);

                                                }
                                                else
                                                    $(subContainer).attr('' + w + '', menuJson[x][y][z][w]);
                                            }

                                        }
                                        // when more childs
                                        else {
                                            if (firstSubChildFlag) {
                                                var subChildcontainer = $("<ul></ul>");
                                                $(subChildcontainer).attr('id', subChildId);
                                                $(subChildcontainer).attr('data-level', 2);
                                                firstSubChildFlag = 0;
                                            }
                                            for (v in menuJson[x][y][z][w]) {

                                                for (u in menuJson[x][y][z][w][v]) {
                                                    if (menuJson[x][y][z][w][v].hasOwnProperty(u)) {
                                                        // not null properties
                                                        if (menuJson[x][y][z][w][v][u]) {

                                                            if (u == "url")
                                                                $(link).attr('href', menuJson[x][y][z][w][v][u]);
                                                            else if (u == "name") {
                                                                var linkContainer = $("<li></li>");
                                                                var link = $("<a></a>");
                                                                $(link).css('display', 'inline-block')
																               .css('width', '100%');
                                                                $(link).html(menuJson[x][y][z][w][v][u]);
                                                            }

                                                        }
                                                    }
                                                    $(linkContainer).append(link);
                                                    $(subChildcontainer).append(linkContainer);
                                                }

                                            }

                                        }
                                    }

                                }

                            }
                            //$(subContainer).append(subChildcontainer);
                        }
                        $(container).append(subContainer);
                        $(container).append(subChildcontainer);
                    }
                    //$(subMenuContainer).append(container);

                }

                $(menuContainer).append(subMenuContainer);
                $(menuContainer).append(container);
            }

        }

    }

}

$('#cbp-spmenu-s1').append(menuContainer);


var menuLeft = document.getElementById('cbp-spmenu-s1'),
body = document.getElementById('bodyContent'), prevMenu = '', prevMmenu = '', initiator = 0, slp = $('#showLeftPush');
slp.on('mouseover', function () {
    $(menuLeft).show();
    $(this).addClass('active');
    classie.toggle(body, 'cbp-spmenu-push-toright');
    classie.toggle(menuLeft, 'cbp-spmenu-open');
   
    $(this).hide();
    $('#cbp-spmenu-s1').css({ 'border': 'solid 2px #A4D3EE', 'border-top-right-radius': '20px', 'border-bottom-right-radius': '20px' });
    // var windowWidth = window.innerWidth;
    // var menuWidth = parseInt($('#cbp-spmenu-s1').css('width'), 10);
    // var marginLeft = parseInt( $('#rightContainer').css('margin-left') , 10 );
    // $('.iframeContent').attr('width', windowWidth - menuWidth - marginLeft - 20);

});

$(menuLeft).on('mouseleave', function () {

    setTimeout(function () {
        if (slp.hasClass('active')) {
            //slp.trigger('mouseover');
            slp.removeClass('active');
            slp.show();
            $(menuLeft).removeClass('cbp-spmenu-open');
            $(menuLeft).hide();
            $('#bodyContent').removeClass('cbp-spmenu-push-toright');
            sessionStorage.menuOpen = false;
            $(menuLeft).css({ 'border': 'solid 0px #A4D3EE' });
       }
    }, leftMenuOpeningDelayInSec * 100);
    

});

$('#acLink').on('click', function () {
    $('#acLinkSub').slideToggle();
});
$('#sysTop').on('mouseover', function () {
    $(this).find('ul').css({ 'left': 'auto', 'position': 'absolute', 'top': '62px' });
}).on('mouseout', function () {
    $(this).find('ul').css({ 'left': '-999px', 'position': 'absolute' });
});

$('.flyoutnav').find('span').each(function () {
    var subDiv = $(this).find('div');
    $(this).hover(function () {
        subDiv.stop().slideDown();
    }, function () {
        subDiv.stop().slideUp();
    });
});

$('nav ul li').on('click', function (event, triggeredflag) {
    var crObj = $(this), crDtop = crObj.attr('data-top');
    if (crDtop && initiator === 0) {
        $('#' + crDtop).trigger('click', [triggeredflag]);
        return;
    }
    initiator = 0;
    resetMain(crObj, crObj.attr('id'));
    id1 = $(this).attr('data');

    // only if it is not triggered thru menu init
    if (triggeredflag != 1) {

        if (typeof (id1) != 'undefined') {
            if (typeof (sessionStorage['' + id1 + '']) == 'undefined' || sessionStorage['' + id1 + ''] == 'false')
                sessionStorage['' + id1 + ''] = true;
            else if (sessionStorage['' + id1 + ''])
                sessionStorage['' + id1 + ''] = false;
        }

		setTimeout(function() {
      intiScroll();
}, 500);
	
    }


});
$("ul[data-level='2']").css('list-style-image', 'none');

$('#menu-rpx-menu').find('li').on('click', function (event, triggeredflag) {
    if (!slp.hasClass('active'))
        slp.trigger('mouseover');
    prevMmenu != '' ? prevMmenu.css({ 'background-color': '#007DC3' }) : '';
    prevMmenu = $(this);
    initiator = 1;
    prevMmenu.css({ 'background-color': '#205081' });
    dispSelMenu(prevMmenu);
    $('#' + prevMmenu.attr('data')).trigger('click');

    if (typeof (triggeredflag) == 'undefined')
        sessionStorage['selectedMainMenuId'] = $(this).attr('id');
});

dispSelMenu = function (obj) {
    for (i in mnMenus) {
        var cmenu = $('#' + mnMenus[i])
        cmenu.hide();
        $('#' + cmenu.attr('data')).hide();
    }
    obj.show();
    $('#' + obj.attr('data')).show();
}
setMenu = function (obj) {
    if ((obj.css('list-style-image')).indexOf('arrowdwn') !== -1) {
        obj.css({ 'list-style-image': 'url(/_layouts/RPXDev/Images/arrowrgt.png)', 'background-color': '#007dc3' });
        $('#' + obj.attr('data')).slideUp();
    } else if ((obj.css('list-style-image')).indexOf('arrowrgt') !== -1) {
        obj.css({ 'list-style-image': 'url(/_layouts/RPXDev/Images/arrowdwn.png)', 'background-color': '#205081' });
        $('#' + obj.attr('data')).slideDown();
    } else {
        prevMenu != '' ? prevMenu.css({ 'background-color': '#007dc3' }) : '';
        obj.css({ 'background-color': '#205081' });
        prevMenu = obj;
        //console.log(obj.attr('data-click'));
        /*if(obj.attr('data-click') !== 'acqPost')
        $('#rightContainer').html(obj.text() + ' Under Process');
        else 
        $('#rightContainer').html('<img src=images/report.jpg />')*/
    }
}
resetMain = function (main, id) {
    if (!id) {
        //resetSub(main);
        setMenu(main);
        return;
    }
    for (i in mnMenus) {
        var cmenu = $('#' + mnMenus[i]);
        if (mnMenus[i] !== id && cmenu.css('list-style-image').indexOf('arrowdwn') !== -1) {
            setMenu(cmenu);
            cmenu.css({ 'background-color': '#007dc3' });
        } else if (mnMenus[i] === id) {
            cmenu.css({ 'background-color': '#007dc3' });
        }
    }
    setMenu(main);
}
resetSub = function (obj) {
    var items = $('#' + obj.parent().attr('id')).find('li:not(:has(a))').each(function () {
        if ($(this).css('list-style-image').indexOf('arrowdwn') !== -1)
            $('#' + $(this).attr('data')).slideUp().find('li').each(function () {
                $(this).css({ 'background-color': '#007dc3' })
            });
        $(this).css({ 'list-style-image': 'url(/_layouts/RPXDev/Images/arrowrgt.png)', 'background-color': '#007dc3' });
    });
}


function menuInit() {
    // setting the top of left menu panel
    $(document).ready( function () {
                     if ($('#s4-ribbonrow').is(':visible'))
                    var top = $('#s4-ribbonrow').outerHeight() + $('#s4-titlerow').outerHeight() + 10;
                else
                    var top = $('#s4-titlerow').outerHeight() + 10;


                //$('#cbp-spmenu-s1').css('top', top);
                // setting account menu top
                var top = $('#acLink').position().top + $('#acLink').outerHeight() - 10;

                $('#acLinkSub').css('top', top);

                $(document).on('click', '#showLeftPush', function () {
                    sessionStorage.menuOpen = true;
                });

                /*if( sessionStorage.menuOpen == "true" ){
                $('#showLeftPush').addClass('active');
                $('#showLeftPush').css('display', 'none');
                $('#bodyContent').addClass('cbp-spmenu-push-toright');
                $('#cbp-spmenu-s1').addClass('cbp-spmenu-open');
                $('#cbp-spmenu-s1').css('border', '2px solid rgb(164, 211, 238)');
                $('#cbp-spmenu-s1').css('border-top-right-radius', '20px');
                $('#cbp-spmenu-s1').css('border-bottom-right-radius', '20px');
                var windowWidth = window.innerWidth;
                var menuWidth = parseInt($('#cbp-spmenu-s1').css('width'), 10);
                var marginLeft = parseInt($('#rightContainer').css('margin-left'), 10);
        
                $('.iframeContent').attr('width', windowWidth - menuWidth - marginLeft - 20);

                }*/

                $('nav ul').find('li').each(function () {
                    var openMenuId = $(this).attr('data');

                    if (sessionStorage['' + openMenuId + ''] && typeof (openMenuId) != 'undefined'
			            && openMenuId != $('#' + ($('#' + sessionStorage['selectedMainMenuId']).attr('data'))).attr('data')) {
                        $(this).trigger('click', [1]);
                    }
                });

                $('nav ul li').find('a').each(function () {
                    if ($(this).attr('href') == window.location)
                        $(this).parent().css('background-color', 'rgb(32, 80, 129)');
                });

                //console.log( $('#'+sessionStorage['selectedMainMenuId']+'') );

                $('#' + sessionStorage['selectedMainMenuId'] + '').trigger('click', [1]);
                //$('#'+sessionStorage['selectedMainMenuId']+'').trigger('click', [1]);
                //$('#'+sessionStorage['selectedMainMenuId']+'').trigger('click');

	            setTimeout(function() {
                  intiScroll();
                }, 500);
    
    } );

   
}

function scaleUp(){
    var width = parseInt($('.container-rpx').width())
    var winWidth = parseInt($(window).width());
    if (width < winWidth) { width = winWidth }
    $('#bodyContent').css({ 'width': width + 'px' });

    var contentHeight = parseInt($('.container-rpx').height());
    var winHeight = parseInt($(window).height());
    if (contentHeight < 510) { contentHeight = winHeight }
    $('.container-rpx').css({ 'height': contentHeight + 'px' });


}

function intiScroll()
{
	// Do something after 5 seconds
      var comment_scroll;
		     // for initial initialization of scroll
        if(!comment_scroll ){
            comment_elem = $('#cbp-spmenu-s1');
            comment_scroll = comment_elem.jScrollPane();
        } 

        // for re-initialization of scroll
        else {
         var api = comment_elem.data('jsp');
            api.reinitialise();
        }
}

/*$(document).ready(function () {
    scaleUp();

});

$(window).resize(function () {
    scaleUp();
});*/

menuInit();
			