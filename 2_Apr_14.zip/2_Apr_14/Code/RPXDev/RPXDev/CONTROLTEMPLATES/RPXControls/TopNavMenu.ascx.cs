﻿using System;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using Microsoft.SharePoint;
using Microsoft.SharePoint.WebControls;
using Microsoft.SharePoint.Publishing;
using System.Linq;
using System.Web;
using System.IO;
using System.Text;
using Microsoft.SharePoint.WebPartPages;
using Microsoft.Office.Excel.WebUI;
using System.Net;
using System.Configuration;
using System.Collections.Generic;
using Newtonsoft.Json;
using Newtonsoft.Json.Serialization;


namespace RPXDev.CONTROLTEMPLATES.RPXControls
{
    public partial class TopNavMenu : UserControl
    {
        public string MenuJson { get; set; }
        public string UserName 
        {
            get
            {
                try
                {
                    return SPContext.Current.Web.CurrentUser.Name;
                }
                catch (Exception)
                {
                    return "User";
                }
               
            }
        }
        public string DefaultGroup { get; set; }
        public string SubMenuItesmsMaster { get; set; }
        public string LeftMenuOpeningDelayInSec { get; set; }

        protected void Page_Load(object sender, EventArgs e)
        {
            DefaultGroup = ConfigurationManager.AppSettings["DefaultGroup"];
            LeftMenuOpeningDelayInSec = ConfigurationManager.AppSettings["LeftMenuOpeningDelayInSec"];

            LoadMenu();
        }
        private void LoadMenu()
        {
            List<MenuItem> lstMenu = new List<MenuItem>();
            SPUser curUser = SPContext.Current.Web.CurrentUser;

            SPSecurity.RunWithElevatedPrivileges(delegate()
           {
               using (SPSite oSite = new SPSite(SPContext.Current.Web.Site.ID))
               {
                   StringBuilder sbQuery = new StringBuilder();
                   sbQuery.Append("<Where><Eq><FieldRef Name ='ContentType'/>");
                   sbQuery.Append("<Value Type='Text'>RPXDev - RPXCustomPageLayoutCT</Value>");
                   sbQuery.Append("</Eq></Where>");

                   SPListItemCollection items = null;
                   SPQuery camlQuery = new SPQuery(); ;
                   camlQuery.Query = sbQuery.ToString();
                   int count = 1;

                   foreach (SPWeb oWeb in oSite.AllWebs)
                   {
                       if (PublishingWeb.IsPublishingWeb(oWeb))
                       {
                           PublishingWeb oPublishingWeb = PublishingWeb.GetPublishingWeb(oWeb);
                           items = oPublishingWeb.PagesList.GetItems(camlQuery);

                           MenuItem oMenu = new MenuItem() { Name = oWeb.Title, Datatop = "top_" + count++, Id = "main_" + count++, ChildId = "lvl1_sub_" + count++, };
                           if (items != null && items.Count > 0)
                           {
                               var result = items.OfType<SPListItem>()
                                 .Select(subMenuItem => new MenuItem()
                                 {
                                     Name = Convert.ToString(subMenuItem["PageDisplayName"]),
                                     Url = oWeb.Url + "/Pages/" + subMenuItem["Name"],
                                     Members = new SPFieldUserValueCollection(oWeb, Convert.ToString(subMenuItem["TargetAudience"])),
                                     SubMenuGroup = subMenuItem["SubMenuGroup"] != null ? subMenuItem["SubMenuGroup"].ToString().Split('#').Last() : null

                                 }).ToList();

                               if (result != null && result.Count > 0)
                               {
                                   List<string> lstGroupNames = new List<string>();
                                   Dictionary<string,List<MenuItem>> dicSubMenuLvl2 = new Dictionary<string,List<MenuItem>>();
                                   result.ForEach(m => {
                                       if (!string.IsNullOrEmpty(m.SubMenuGroup))
                                       {
                                           if (dicSubMenuLvl2.ContainsKey(m.SubMenuGroup))
                                           {
                                               dicSubMenuLvl2[m.SubMenuGroup].Add(m);
                                           }
                                           else
                                           {
                                               dicSubMenuLvl2[m.SubMenuGroup] = new List<MenuItem>();
                                               dicSubMenuLvl2[m.SubMenuGroup].Add(m);
                                           }
                                       }
                                   });
                                   //oMenu.Child = new List<MenuItem>();

                                   foreach (KeyValuePair<string, List<MenuItem>> item in dicSubMenuLvl2)
                                   {
                                       var subMenuLvl1=new MenuItem() { Name=item.Key,ChildId="lvl2_sub_"+count++ };
                                       
                                       foreach (var lvl3MenuItem in item.Value)
                                       {
                                           foreach (SPFieldUserValue group in lvl3MenuItem.Members)
                                           {
                                               //check if group is already present in the list 
                                               //otherwise check membership of this user group for current user
                                               if (!lstGroupNames.Contains(group.LookupValue))
                                               {
                                                   if (IsMemberOfGroup(oWeb, curUser, group.LookupValue))
                                                   {
                                                       lstGroupNames.Add(group.LookupValue);
                                                   }
                                               }
                                               if (lstGroupNames.Contains(group.LookupValue) && !subMenuLvl1.Child.Contains(lvl3MenuItem))
                                               {
                                                   subMenuLvl1.Child.Add(lvl3MenuItem);
                                                   break;
                                               }
                                           }
                                       }
                                       if (subMenuLvl1.Child.Count > 0)
                                       {
                                           oMenu.Child.Add(subMenuLvl1); 
                                       }
                                       
                                   }
                               }

                           }

                           if (oMenu.Child.Count > 0 && !oWeb.IsRootWeb)
                           {
                               lstMenu.Add(oMenu);
                           }
                       }
                   }
                   MenuJson = JsonConvert.SerializeObject(lstMenu, new JsonSerializerSettings()
                   {
                       ContractResolver = new CamelCasePropertyNamesContractResolver(),
                       PreserveReferencesHandling = PreserveReferencesHandling.None
                   });

               }
           });

        }
        private bool IsMemberOfGroup(SPWeb web, SPUser usr, string groupName)
        {
            if (string.IsNullOrEmpty(groupName))
                return false;

            try
            {
                web.EnsureUser(usr.LoginName);
                SPGroup spGroup = null;
                using (SPSite oSite = new SPSite(web.Site.ID, usr.UserToken))
                {
                    using (SPWeb oWeb = oSite.OpenWeb())
                    {
                        spGroup = oWeb.SiteGroups[groupName];
                        if (spGroup != null && oWeb.IsCurrentUserMemberOfGroup(spGroup.ID))
                            return true;
                    }
                }
            }
            catch (Exception)
            {
                return false;
            }
           
            return false;
        }
    }

    public class MenuItem
    {
        [JsonProperty("name",Order=1)]
        public string Name { get; set; }
        
        [JsonProperty("data-top",Order=2)]
        public string Datatop { get; set; }
        
        [JsonProperty("id", Order = 3)]
        public string Id { get; set; }
        
        [JsonProperty("child-id",Order=4)]
        public string ChildId { get; set; }
       
        [JsonProperty("child",Order=5)]
        public List<MenuItem> Child { get; set; }
       
        [JsonProperty("url",Order=6)]
        public string Url { get; set; }
       
        [JsonIgnore]
        public SPFieldUserValueCollection Members { get; set; }
       
        [JsonIgnore]
        public string SubMenuGroup { get; set; }

        public MenuItem()
        {
            this.Child = new List<MenuItem>();
        }
    }
     
}
