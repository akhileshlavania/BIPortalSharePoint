﻿using System;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using Microsoft.SharePoint;
using Microsoft.SharePoint.WebControls;
using Microsoft.SharePoint.Publishing;
using System.Linq;
using System.Web;
using System.IO;
using System.Text;
using Microsoft.SharePoint.WebPartPages;
using Microsoft.Office.Excel.WebUI;
using System.Net;
using System.Configuration;
using System.Collections;
using System.Collections.Generic;
using Newtonsoft.Json;
using Newtonsoft.Json.Serialization;

namespace RPXDev.CONTROLTEMPLATES.RPXControls
{
    public partial class ReportEditorUC : UserControl
    {
        public string MSTRBaseUrl { get; set; }
        public string SalesforceBaseUrl { get; set; }
        public string TableauBaseUrl { get; set; }
        public string PDFBiPortalBaseUrl { get; set; }
        public string PDFNetworkPathBaseUrl { get; set; }
        public string ExcelBIPortalBaseUrl { get; set; }
        public string ExcelNetworkPathBaseUrl { get; set; }
        public string RegPreInstallationScriptUrl { get; set; }

        public string MSTRValidationBaseUrl { get; set; }
        public string SalesforceValidationBaseUrl { get; set; }
        public string TableauValidationBaseUrl { get; set; }
        public string PDFBiPortalValidationBaseUrl { get; set; }
        public string PDFNetworkPathValidationBaseUrl { get; set; }
        public string ExcelBIPortalValidationBaseUrl { get; set; }
        public string ExcelNetworkPathValidationBaseUrl { get; set; }

        public string InValidSubMenuIds { get; set; }
        Dictionary<string, ReportMarkup> m_Markups;
        Report m_Report;
        string m_MSTRUserName = null;//"ajammi";
        string m_MSTRPasswd = null;//"F2u@5S34X*";

        protected void Page_Load(object sender, EventArgs e)
        {
            m_MSTRUserName = ConfigurationManager.AppSettings["MSTRUsername"];
            m_MSTRPasswd = ConfigurationManager.AppSettings["MSTRPassword"];
            RegPreInstallationScriptUrl = SPContext.Current.Site.Url + "/" + ConfigurationManager.AppSettings["PreInstallationScriptsDocLib"]
                                          + "/" + ConfigurationManager.AppSettings["SLRegFileName"];

           
            LoadReportTemplate();
            LoadBaseUrl();

            if (SPContext.Current.FormContext.FormMode == SPControlMode.Display)
            {
                SetDisplayModeContent();
                PublishCurrentPage();
            }
            else
            {
                LoadValidationBaseUrls();
                LoadSubMenuMasterData();
            }

        }

        private void LoadSubMenuMasterData()
        {
            var lstInValidSubMenuIds = new List<int>();
            SPWeb oWeb = SPContext.Current.Web.Site.RootWeb;
            string curWebTitle = SPContext.Current.Web.Title.ToLower();

            if (ConfigurationManager.AppSettings.AllKeys.Contains("SubMenuList"))
            {
                var lstSubMenuGroups = oWeb.Lists.TryGetList(ConfigurationManager.AppSettings["SubMenuList"]);
                if (lstSubMenuGroups != null)
                {

                    lstInValidSubMenuIds = lstSubMenuGroups.Items.OfType<SPListItem>()
                      .Where(m => Convert.ToString(m["MenuName"]).Trim().ToLower() != curWebTitle)
                      .Select(lstItem => lstItem.ID).ToList();
                }
            }
            InValidSubMenuIds = JsonConvert.SerializeObject(lstInValidSubMenuIds, new JsonSerializerSettings()
            {
                ContractResolver = new CamelCasePropertyNamesContractResolver(),
                PreserveReferencesHandling = PreserveReferencesHandling.None
            });

        }

        private void LoadValidationBaseUrls()
        {
            MSTRValidationBaseUrl = JsonConvert.SerializeObject(ConfigurationManager.AppSettings["MSTRValidationBaseUrl"].Split(new char []{';'}, StringSplitOptions.RemoveEmptyEntries), new JsonSerializerSettings()
            {
                ContractResolver = new CamelCasePropertyNamesContractResolver(),
                PreserveReferencesHandling = PreserveReferencesHandling.None
            });

            SalesforceValidationBaseUrl = JsonConvert.SerializeObject(ConfigurationManager.AppSettings["SalesforceValidationBaseUrl"].Split(new char []{';'}, StringSplitOptions.RemoveEmptyEntries), new JsonSerializerSettings()
            {
                ContractResolver = new CamelCasePropertyNamesContractResolver(),
                PreserveReferencesHandling = PreserveReferencesHandling.None
            });

            TableauValidationBaseUrl = JsonConvert.SerializeObject(ConfigurationManager.AppSettings["TableauValidationBaseUrl"].Split(new char []{';'}, StringSplitOptions.RemoveEmptyEntries), new JsonSerializerSettings()
            {
                ContractResolver = new CamelCasePropertyNamesContractResolver(),
                PreserveReferencesHandling = PreserveReferencesHandling.None
            });

            PDFBiPortalValidationBaseUrl = JsonConvert.SerializeObject(ConfigurationManager.AppSettings["PDFBiPortalValidationBaseUrl"].Split(new char []{';'}, StringSplitOptions.RemoveEmptyEntries), new JsonSerializerSettings()
            {
                ContractResolver = new CamelCasePropertyNamesContractResolver(),
                PreserveReferencesHandling = PreserveReferencesHandling.None
            });

            PDFNetworkPathValidationBaseUrl = JsonConvert.SerializeObject(ConfigurationManager.AppSettings["PDFNetworkPathValidationBaseUrl"].Replace("\\", "\\\\").Split(new char []{';'}, StringSplitOptions.RemoveEmptyEntries), new JsonSerializerSettings()
            {
                ContractResolver = new CamelCasePropertyNamesContractResolver(),
                PreserveReferencesHandling = PreserveReferencesHandling.None
            });

            ExcelBIPortalValidationBaseUrl = JsonConvert.SerializeObject(ConfigurationManager.AppSettings["ExcelBIPortalValidationBaseUrl"].Split(new char []{';'}, StringSplitOptions.RemoveEmptyEntries), new JsonSerializerSettings()
            {
                ContractResolver = new CamelCasePropertyNamesContractResolver(),
                PreserveReferencesHandling = PreserveReferencesHandling.None
            });

            ExcelNetworkPathValidationBaseUrl = JsonConvert.SerializeObject(ConfigurationManager.AppSettings["ExcelNetworkPathValidationBaseUrl"].Replace("\\", "\\\\").Split(new char []{';'}, StringSplitOptions.RemoveEmptyEntries), new JsonSerializerSettings()
            {
                ContractResolver = new CamelCasePropertyNamesContractResolver(),
                PreserveReferencesHandling = PreserveReferencesHandling.None
            });
        }

        private void PublishCurrentPage()
        {
             SPWeb oWeb = SPContext.Current.Web;
             bool bAllowUnsafeUpdates = oWeb.AllowUnsafeUpdates;
             try
             {
                 string pageName = Request.Url.AbsolutePath.Substring(Request.Url.AbsolutePath.LastIndexOf('/'));

                 //read the value from content type
                 oWeb.AllowUnsafeUpdates = true;
                 PublishingWeb publishingWeb = PublishingWeb.GetPublishingWeb(oWeb);
                 var pubPage = publishingWeb.GetPublishingPage(oWeb.Url + "/Pages" + pageName);
                 if (pubPage.ListItem.File.Level != SPFileLevel.Published)
                 {
                     if (pubPage.ListItem.File.Level == SPFileLevel.Checkout)
                     {
                         pubPage.ListItem.File.CheckIn("Page checkedin");
                     }
                     pubPage.ListItem.File.Publish("Page pubslished");
                 }
             }
             catch (Exception ex)
             {

             }
             finally
             {
                 oWeb.AllowUnsafeUpdates = bAllowUnsafeUpdates;
             }
           

        }

        private void LoadReportTemplate()
        {
            m_Markups = new Dictionary<string, ReportMarkup>();
            SPWeb oWeb = SPContext.Current.Web.Site.RootWeb;

            // <add key="ReportMarkUpList" value="ReportMarkup"/>
            if (ConfigurationManager.AppSettings.AllKeys.Contains("ReportMarkUpList"))
            {
                var lstMarkup = oWeb.Lists.TryGetList(ConfigurationManager.AppSettings["ReportMarkUpList"]);
                if (lstMarkup != null)
                {

                    m_Markups = lstMarkup.Items.OfType<SPListItem>()
                      .Select(lstItem => new ReportMarkup()
                      {
                          Name = Convert.ToString(lstItem["ReportType"]),
                          Template = Convert.ToString(lstItem["ReportMarkUp"]),
                          BaseUrl = Convert.ToString(lstItem["BaseUrl"])
                      }).ToDictionary(r => r.Name);
                }
            }

        }

        private void LoadBaseUrl()
        {
            MSTRBaseUrl = m_Markups.ContainsKey("Micro Strategy") ? m_Markups["Micro Strategy"].BaseUrl + "?uid=" + HttpUtility.UrlEncode(m_MSTRUserName) + "&pwd=" + HttpUtility.UrlEncode(m_MSTRPasswd) : string.Empty; //"http://10.50.168.173:8080/MicroStrategy/servlet/mstrWeb?uid=ajammi&pwd=F2u@5S34X*";
            SalesforceBaseUrl = m_Markups.ContainsKey("Sales force") ? m_Markups["Sales force"].BaseUrl : string.Empty;// "https://sso.connect.pingidentity.com/sso/sp/initsso?saasid=2f54d38e-ce98-4847-af14-03279e312cce&idpid=ca86b7bb-dad3-41a1-88d0-d344201871a7";
            TableauBaseUrl = m_Markups.ContainsKey("Tableau") ? m_Markups["Tableau"].BaseUrl : string.Empty;//"https://dv-tbu.rpxcorp.local";
            PDFBiPortalBaseUrl = m_Markups.ContainsKey("Pdf-BIPortal") && !string.IsNullOrEmpty(m_Markups["Pdf-BIPortal"].BaseUrl) ? m_Markups["Pdf-BIPortal"].BaseUrl : SPContext.Current.Web.Site.RootWeb.Url;
            PDFNetworkPathBaseUrl = m_Markups.ContainsKey("Pdf-NetworkPath") ? m_Markups["Pdf-NetworkPath"].BaseUrl.Replace("\\", "/") : string.Empty;
            ExcelBIPortalBaseUrl = m_Markups.ContainsKey("Excel-BIPortal") && !string.IsNullOrEmpty(m_Markups["Excel-BIPortal"].BaseUrl) ? m_Markups["Excel-BIPortal"].BaseUrl : SPContext.Current.Web.Site.RootWeb.Url;
            ExcelNetworkPathBaseUrl = m_Markups.ContainsKey("Excel-NetworkPath") ? m_Markups["Excel-NetworkPath"].BaseUrl.Replace("\\", "/") : string.Empty;

        }
        private void SetDisplayModeContent()
        {
            divContent.InnerHtml = string.Empty;
            //get page name
            string pageName = Request.Url.AbsolutePath.Substring(Request.Url.AbsolutePath.LastIndexOf('/'));

            //read the value from content type
            SPWeb oWeb = SPContext.Current.Web;
            PublishingWeb publishingWeb = PublishingWeb.GetPublishingWeb(oWeb);
            var pubPage = publishingWeb.GetPublishingPage(oWeb.Url + "/Pages" + pageName);
            m_Report = new Report(pubPage.ListItem);

            switch (m_Report.Type)
            {
                case "Sales force":
                    ProcessSalesforceReport();
                    break;
                case "Tableau":
                    ProcessTableueReport();
                    break;
                case "Micro Strategy":
                    ProcessMicroStrategyReport();
                    break;
                case "Pdf-BIPortal":
                    ProcessPdfReport();
                    break;
                case "Excel-BIPortal":
                    ProcessExcelReport();
                    break;
                case "Pdf-NetworkPath":
                    ProcessPdfFromNetworkPath();
                    break;
                case "Excel-NetworkPath":
                    ProcessExcelFromNetworkPath();
                    break;
                default:
                    break;
            }
        }

        private string GetReportMarkup(string reportType)
        {
            if (m_Markups.ContainsKey(reportType))
            {
                return m_Markups[reportType].Template;
            }

            return string.Empty;
        }

        private void SetContent(string reportType, string url)
        {
            StringBuilder sbMarkup = new StringBuilder(GetReportMarkup(reportType));
            if (!string.IsNullOrEmpty(sbMarkup.ToString()) && !string.IsNullOrEmpty(url))
            {
                sbMarkup = sbMarkup.Replace("$source$", url)
               .Replace("$height$", m_Report.Height.ToString())
               .Replace("$width$", "100%");
            }
            divContent.InnerHtml = sbMarkup.ToString();
        }


        private void ProcessSalesforceReport()
        {
            string path = m_Report.Path;
            if (m_Report.Path.LastIndexOf('?') > -1)
            {
                SetContent("Sales force", m_Report.Path.Substring(0, m_Report.Path.LastIndexOf('?') - 1) + "?isdtp=mn");
            }
            else
            {
                SetContent("Sales force", m_Report.Path + "?isdtp=mn");
            }

        }

        private void ProcessPdfReport()
        {
            SetContent("Pdf-BIPortal", m_Report.BIPortalPdfReportConfigUrl);
        }

        private void ProcessPdfFromNetworkPath()
        {
            if (!string.IsNullOrEmpty(m_Report.NetworkPathPdfReportConfigUrl))
            {
                SPWeb oWeb = SPContext.Current.Web;
                SPSecurity.RunWithElevatedPrivileges(delegate()
                {
                    using (SPSite site = new SPSite(oWeb.Site.ID))
                    {
                        using (SPWeb web = site.RootWeb)
                        {
                            string fileName = m_Report.NetworkPathPdfReportConfigUrl.Substring(m_Report.NetworkPathPdfReportConfigUrl.LastIndexOf('\\') + 1);
                            string uploadedDocUrl = SPWebUtility.UpLoadToDocLib(web, ConfigurationManager.AppSettings["TempDocLibName"], fileName, File.ReadAllBytes(m_Report.NetworkPathPdfReportConfigUrl));//.Replace("/", "\\")));

                            if (!string.IsNullOrEmpty(uploadedDocUrl))
                            {
                                SetContent("Pdf-NetworkPath", uploadedDocUrl);
                            }
                        }
                    }

                });
            }

        }

        private void ProcessExcelFromNetworkPath()
        {
            if (!string.IsNullOrEmpty(m_Report.NetworkExcelReportConfigUrl))
            {
                SPWeb oWeb = SPContext.Current.Web;
                SPSecurity.RunWithElevatedPrivileges(delegate()
                {
                    using (SPSite site = new SPSite(oWeb.Site.ID))
                    {
                        using (SPWeb web = site.RootWeb)
                        {
                            string fileName = m_Report.NetworkExcelReportConfigUrl.Substring(m_Report.NetworkExcelReportConfigUrl.LastIndexOf('\\') + 1);
                            string uploadedDocUrl = SPWebUtility.UpLoadToDocLib(web, ConfigurationManager.AppSettings["TempDocLibName"], fileName, File.ReadAllBytes(m_Report.NetworkExcelReportConfigUrl));//.Replace("/", "\\")));

                            if (!string.IsNullOrEmpty(uploadedDocUrl))
                            {
                                string finalUrl = oWeb.Url + "/_layouts/RPXxlviewer.aspx?id=" + uploadedDocUrl;

                                SetContent("Excel-NetworkPath", finalUrl);
                            }
                        }
                    }

                });
            }
        }

        private void ProcessExcelReport()
        {
            SPWeb oWeb = SPContext.Current.Web;
            string finalUrl = oWeb.Url + "/_layouts/RPXxlviewer.aspx?id=" + m_Report.BIPortalExcelReportConfigUrl;

            SetContent("Excel-BIPortal", finalUrl);
        }

        private void ProcessMicroStrategyReport()
        {
            //string userName = "ajammi";
            //string passwd = "F2u@5S34X*";
            string footerHeader = "header,path,footer";
            string serverQueryString = ConfigurationManager.AppSettings["MSTRQueryStringServerName"];//"&server=DVDAE-MST20A&Project=RPX%20Internal&port=0&share=1";

            string finalUrl = string.Empty;
            if (!m_Report.MSTRReportConfigUrl.Contains("&server=") && !m_Report.MSTRReportConfigUrl.Contains("&Project=") && !m_Report.MSTRReportConfigUrl.Contains("&port=") && !m_Report.MSTRReportConfigUrl.Contains("&share="))
            {
                finalUrl = m_Report.MSTRReportConfigUrl + serverQueryString + "&hiddenSections=" + footerHeader + "&uid=" + HttpUtility.UrlEncode(GetMSTRUserName()) + "&pwd=" + HttpUtility.UrlEncode(GetMSTRUserPwd());

            }
            else
            {
                finalUrl = m_Report.MSTRReportConfigUrl + "&hiddenSections=" + footerHeader + "&uid=" + HttpUtility.UrlEncode(GetMSTRUserName()) + "&pwd=" + HttpUtility.UrlEncode(GetMSTRUserPwd());
            }

            SetContent("Micro Strategy", finalUrl);//m_Report.MSTRReportConfigUrl + serverQueryString + "&hiddenSections=" + footerHeader + "&uid=" + GetMSTRUserName() + "&pwd=" + GetMSTRUserPwd());
        }

        private string GetMSTRUserName()
        {
            if (Convert.ToBoolean(ConfigurationManager.AppSettings["MSTRImpersonationEnabled"]))
            {
                return m_MSTRUserName;
            }

            return SPContext.Current.Web.CurrentUser.LoginName;
        }

        private string GetMSTRUserPwd()
        {
            if (Convert.ToBoolean(ConfigurationManager.AppSettings["MSTRImpersonationEnabled"]))
            {
                return m_MSTRPasswd;
            }

            return null;
        }

        private void ProcessTableueReport()
        {
            if (!string.IsNullOrEmpty(m_Report.TableauReportConfigUrl))
            {
                string http = m_Report.TableauReportConfigUrl.Substring(0, m_Report.TableauReportConfigUrl.IndexOf("//"));
                string sub = m_Report.TableauReportConfigUrl.Substring(m_Report.TableauReportConfigUrl.IndexOf("//") + 2);
                string tabServer = sub.Substring(0, sub.IndexOf('/'));
                string afterTabServerVal = sub.Substring(sub.IndexOf('/'));
                string tabUser = GetTbaleauUser();//ConfigurationManager.AppSettings["TableauUserName"]; //@"rpx\ajammi";
                string errMsg = null;
                string tckt = GetTableauTicket("http://" + tabServer, tabUser, ref errMsg);

                string finalUrl = http + "//" + tabServer + "/trusted/" + tckt + afterTabServerVal;

                SetContent("Tableau", finalUrl);
            }
        }

        private string GetTbaleauUser()
        {
            if (Convert.ToBoolean(ConfigurationManager.AppSettings["TableauImpersonationEnabled"]))
            {
                return ConfigurationManager.AppSettings["TableauUserName"];
            }

            return SPContext.Current.Web.CurrentUser.LoginName;
        }
        private string GetTableauTicket(string tabserver, string tabuser, ref string errMsg)
        {
            // ServicePointManager.SecurityProtocol = SecurityProtocolType.Ssl3;
            ASCIIEncoding enc = new ASCIIEncoding();
            // the client_ip parameter isn't necessary to send in the POST unless you have
            // wgserver.extended_trusted_ip_checking enabled (it's disabled by default)
            string postData = "username=" + tabuser + "&client_ip=" + Page.Request.UserHostAddress;
            byte[] data = enc.GetBytes(postData);

            try
            {
                //string http = _tabssl ? "https://" : "http://";
                HttpWebRequest req = (HttpWebRequest)WebRequest.Create(tabserver + "/trusted");

                req.Method = "POST";
                req.ContentType = "application/x-www-form-urlencoded";
                req.ContentLength = data.Length;

                // Write the request
                Stream outStream = req.GetRequestStream();
                outStream.Write(data, 0, data.Length);
                outStream.Close();

                // Do the request to get the response
                HttpWebResponse res = (HttpWebResponse)req.GetResponse();
                StreamReader inStream = new StreamReader(res.GetResponseStream(), enc);
                string resString = inStream.ReadToEnd();
                inStream.Close();

                return resString;
            }
            // if anything bad happens, copy the error string out and return a "-1" to indicate failure
            catch (Exception ex)
            {
                errMsg = ex.ToString();
                return "-1";
            }
        }

    }
}
