using System;
using System.Runtime.InteropServices;
using System.Security.Permissions;
using Microsoft.SharePoint;
using Microsoft.SharePoint.Security;
using System.Configuration;
using System.Xml.Linq;
using Microsoft.SharePoint.Publishing;

namespace RPXDev.Features.RPXPageLayoutFeature
{
    /// <summary>
    /// This class handles events raised during feature activation, deactivation, installation, uninstallation, and upgrade.
    /// </summary>
    /// <remarks>
    /// The GUID attached to this class may be used during packaging and should not be modified.
    /// </remarks>

    [Guid("88862353-8a63-41d2-930c-104efaaf0d1f")]
    public class RPXPageLayoutFeatureEventReceiver : SPFeatureReceiver
    {
        // Uncomment the method below to handle the event raised after a feature has been activated.

        public override void FeatureActivated(SPFeatureReceiverProperties properties)
        {
            SPSite oSite = properties.Feature.Parent as SPSite;
            if (oSite != null)
            {
                SPWebUtility.SetCustomMasterPage(oSite.RootWeb, "RPX.master", false);
               // SPWebUtility.SetWelcomePageForPubSite(oSite.RootWeb,"Home.aspx");

                UpdateLookUpField(oSite.RootWeb);

                //create the temporary document library to upload excel files from UNC path
                SPWebUtility.CreateDocLib(oSite.RootWeb, ConfigurationManager.AppSettings["TempDocLibName"], "");
            }
        }

        private void UpdateLookUpField(SPWeb web)
        {

            SPField lookupField = web.Fields.TryGetFieldByStaticName("SubMenuGroup");

            if (lookupField != null)
            {
                // Getting Schema of field
                XDocument fieldSchema = XDocument.Parse(lookupField.SchemaXml);

                // Get the root element of the field definition
                XElement root = fieldSchema.Root;

                // Check if list definition exits exists
                if (root.Attribute("List") != null)
                {
                    // Getting value of list url
                    string listName = ConfigurationManager.AppSettings["SubMenuList"]; //"SubMenuGroups";//root.Attribute("List").Value;

                    // Get the correct folder for the list
                    SPList listFolder = web.Lists[listName]; //.GetFolder(listurl);
                    if (listFolder != null)
                    {
                        // Setting the list id of the schema
                        XAttribute attrList = root.Attribute("List");
                        if (attrList != null)
                        {
                            // Replace the url wit the id
                            attrList.Value = listFolder.ID.ToString();
                        }

                        //// Setting the souce id of the schema
                        //XAttribute attrWeb = root.Attribute("SourceID");
                        //if (attrWeb != null)
                        //{
                        //    // Replace the sourceid with the correct webid
                        //    attrWeb.Value = web.ID.ToString();
                        //}

                        // Update field with new schema
                        lookupField.SchemaXml = fieldSchema.ToString();
                    }
                }
            }

        }

        // Uncomment the method below to handle the event raised before a feature is deactivated.

        public override void FeatureDeactivating(SPFeatureReceiverProperties properties)
        {
            SPSite oSite = properties.Feature.Parent as SPSite;
            if (oSite != null)
            {
                SPWebUtility.SetCustomMasterPage(oSite.RootWeb, "v4.master", false);
            }
        }


        // Uncomment the method below to handle the event raised after a feature has been installed.

        //public override void FeatureInstalled(SPFeatureReceiverProperties properties)
        //{
        //}


        // Uncomment the method below to handle the event raised before a feature is uninstalled.

        //public override void FeatureUninstalling(SPFeatureReceiverProperties properties)
        //{
        //}

        // Uncomment the method below to handle the event raised when a feature is upgrading.

        //public override void FeatureUpgrading(SPFeatureReceiverProperties properties, string upgradeActionName, System.Collections.Generic.IDictionary<string, string> parameters)
        //{
        //}
    }
}
