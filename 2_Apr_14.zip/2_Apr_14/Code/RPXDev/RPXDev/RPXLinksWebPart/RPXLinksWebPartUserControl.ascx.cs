﻿using System;
using System.ComponentModel;
using System.Data;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Xml.Serialization;
using System.Web.UI;
using Microsoft.SharePoint;
using Microsoft.SharePoint.WebPartPages;
using System.Linq;
using System.Collections.Generic;
using System.Web.Script.Serialization;

namespace RPXDev.RPXLinksWebPart
{
    public partial class RPXLinksWebPartUserControl : UserControl
    {
        public RPXLinksWebPart WebPart { get; set; }
        public List<UsefulLink> Links { get; set; }
        public JavaScriptSerializer Serializer { get; set; }


        protected void Page_Load(object sender, EventArgs e)
        {
            Serializer = new JavaScriptSerializer();

            try
            {
                using (SPSite oSite = new SPSite(SPContext.Current.Web.Url))
                {
                    using (SPWeb oWeb = oSite.OpenWeb())
                    {

                        if (!string.IsNullOrEmpty(this.WebPart.ListName))
                        {
                            SPList oList = oWeb.Lists[this.WebPart.ListName];  // The display name, ie. "Calendar"  

                            if (oList != null)
                            {
                                Links = oList.Items.OfType<SPListItem>().Select(
                                    linkItem => new UsefulLink() { 
                                    
                                        Title = linkItem.Title,
                                        Url = linkItem["TargetUrl"] !=null? new SPFieldUrlValue(Convert.ToString(linkItem["TargetUrl"])).Url:string.Empty,
                                        IsOpenInNewWindow = linkItem["OpenInNewWindow"] != null ? Convert.ToBoolean(linkItem["OpenInNewWindow"].ToString()) : false,

                                    }).ToList();
                            }

                            
                           
                            //DataTable dt = oList.Items.GetDataTable();

                            //this.gridViewTicketsClosed.DataSource = dt;
                            //this.gridViewTicketsClosed.DataBind();
                        }

                    }
                }
            }
            catch (Exception ex)
            {
            }
        }
        protected void gridViewTicketsClosed_RowDataBound(object sender, System.Web.UI.WebControls.GridViewRowEventArgs e)
        {
            if (e.Row.RowType == DataControlRowType.DataRow)
            {
                HyperLink ddlChoice = e.Row.FindControl("lnkActionLog") as HyperLink;
                Label lblOpen = e.Row.FindControl("lblOpenInNewWindow") as Label;
                if (lblOpen.Text == "True")
                {
                    ddlChoice.Attributes.Add("Target", "_blank");
                }
              
            }
        }
    }

    public class UsefulLink
    {
        public string Title { get; set; }
        public string Url { get; set; }
        public bool IsOpenInNewWindow { get; set; }
        
    }
}
