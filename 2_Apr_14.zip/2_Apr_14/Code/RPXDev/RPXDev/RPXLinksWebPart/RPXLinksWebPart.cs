﻿using System;
using System.ComponentModel;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using Microsoft.SharePoint;
using Microsoft.SharePoint.WebControls;
using Microsoft.SharePoint.WebPartPages;

namespace RPXDev.RPXLinksWebPart
{
    [ToolboxItemAttribute(false)]
    public class RPXLinksWebPart : System.Web.UI.WebControls.WebParts.WebPart
    {
        private string _listName = string.Empty;

        [WebBrowsable(true), WebDisplayName("Enter the List Name"),
           WebDescription(""), DefaultValue(""),
           Personalizable(PersonalizationScope.Shared),
           Category("Custom Properties")]

        public string ListName
        {
            get
            {
                return _listName;
            }
            set
            {
                using (SPSite oSite = new SPSite(SPContext.Current.Web.Url))
                {
                    using (SPWeb oWeb = oSite.OpenWeb())
                    {
                        if (string.IsNullOrEmpty(value) == false)
                        {
                            if (oWeb.Lists.TryGetList(value) == null || oWeb.Lists.TryGetList(value).ContentTypes["RpxLinksCT"] == null)
                            {
                                throw new WebPartPageUserException("Given list is not a valid list !");
                            }
                        }
                        _listName = value;
                    }
                }
            }
        }

        // Visual Studio might automatically update this path when you change the Visual Web Part project item.
        private const string _ascxPath = @"~/_CONTROLTEMPLATES/RPXDev/RPXLinksWebPart/RPXLinksWebPartUserControl.ascx";

        protected override void CreateChildControls()
        {
            Control control = Page.LoadControl(_ascxPath);
            if (control != null)
            {
                ((RPXLinksWebPartUserControl)control).WebPart = this;
            }

            Controls.Add(control);
        }
    }
}
