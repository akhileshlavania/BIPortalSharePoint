﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace RPXDev
{
    public class ReportMarkup
    {
        public string Name { get; set; }
        public string Template { get; set; }
        public string BaseUrl { get; set; }
    }
}
