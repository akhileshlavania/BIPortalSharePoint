﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Microsoft.SharePoint;

namespace RPXDev
{
    public class Report
    {
        public string PageTitle { get; set; }
        public string DisplayName { get; set; }
        public decimal Height { get; set; }
        public decimal  Width { get; set; }
        public string Path { get; set; }
        public string TableauReportConfigUrl { get; set; }
        public string BIPortalPdfReportConfigUrl { get; set; }
        public string NetworkPathPdfReportConfigUrl { get; set; }
        public string BIPortalExcelReportConfigUrl { get; set; }
        public string NetworkExcelReportConfigUrl { get; set; }
        public string MSTRReportConfigUrl { get; set; }
        public string Type { get; set; }
        public string TargetAudience { get; set; }
        public string SubMenuGroup { get; set; }

        public Report(SPListItem item)
        {
            this.DisplayName = Convert.ToString(item["PageDisplayName"]);
            this.PageTitle = Convert.ToString(item["PageTitle"]);
            this.Height = item["PageHeight"]!=null ? Convert.ToDecimal(item["PageHeight"]):800;
           
            this.Width = item["PageWidth"]!=null ?Convert.ToDecimal(item["PageWidth"]):1100;
            this.TableauReportConfigUrl = item["ReportConfigUrl"] != null ? new SPFieldUrlValue(Convert.ToString(item["ReportConfigUrl"])).Url:"";
            this.BIPortalExcelReportConfigUrl = item["ExcelReportUrl"] != null ? new SPFieldUrlValue(Convert.ToString(item["ExcelReportUrl"])).Url : "";
            
            this.NetworkExcelReportConfigUrl = Convert.ToString(item["NetworkExcelFilePath"]);
            this.MSTRReportConfigUrl = item["MSTRReportUrl"] != null ? new SPFieldUrlValue(Convert.ToString(item["MSTRReportUrl"])).Url : "";
            this.BIPortalPdfReportConfigUrl = item["PdfReportUrl"] != null ? new SPFieldUrlValue(Convert.ToString(item["PdfReportUrl"])).Url : "";
            
            this.NetworkPathPdfReportConfigUrl = Convert.ToString(item["NetworkPdfFilePath"]);
            this.Path = Convert.ToString(item["Path"]);
            //this.TargetAudience = Convert.ToString(item["TargetAudience"]);
            this.Type = Convert.ToString(item["ReportType"]);
            this.SubMenuGroup = item["SubMenuGroup"] != null?item["SubMenuGroup"].ToString().Split('#').Last() : null;
        }
    }
}



