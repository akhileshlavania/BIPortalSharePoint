﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Microsoft.SharePoint;
using Microsoft.SharePoint.Utilities;
using Microsoft.SharePoint.Security;
using System.Security.Permissions;
using Microsoft.SharePoint.Publishing;

namespace RPXDev
{
    public class SPWebUtility
    {
        [SharePointPermission(SecurityAction.LinkDemand, ObjectModel = true)]
        public static bool SetCustomMasterPage(SPWeb web, string masterPageUrl, bool useRootSiteGallery)
        {
            SPWeb currentWeb = null;
            string serverRelativeMasterPageUrl = string.Empty;
            SPFile customMasterPage = null;
            if (useRootSiteGallery)
                currentWeb = web.Site.RootWeb;

            else
                currentWeb = web;

            serverRelativeMasterPageUrl = SPEncode.UrlDecodeAsUrl(string.Format("{0}/_catalogs/masterpage/{1}",
                currentWeb.ServerRelativeUrl.Equals("/") ? string.Empty : currentWeb.ServerRelativeUrl, masterPageUrl));
            customMasterPage = currentWeb.GetFile(serverRelativeMasterPageUrl);
            if (customMasterPage.Exists)
            {
                web.CustomMasterUrl = serverRelativeMasterPageUrl;
                web.Update();
                return true;
            }
            else
            {
                // Master Page is not present in this site's master page gallery
                return false;
            }
        }

        public static void SetWelcomePageForPubSite(SPWeb rootWeb, string pageName)
        {
            if (PublishingWeb.IsPublishingWeb(rootWeb))
            {
                PublishingSite pSite = new PublishingSite(rootWeb.Site);
                SPContentType ctype = pSite.ContentTypes["Welcome Page"];
                PageLayoutCollection pageLayouts = pSite.GetPageLayouts(ctype, true);
                PageLayout pageLayout = pageLayouts["/_catalogs/masterpage/welcomesplash.aspx"];
                PublishingWeb pWeb = PublishingWeb.GetPublishingWeb(rootWeb);
                PublishingPageCollection pPages = pWeb.GetPublishingPages();
                PublishingPage pPage = pPages.Add("Home.aspx", pageLayout);
                SPListItem newpage = pPage.ListItem;
                newpage["Title"] = "Page added programmatically";
                newpage.Update();

               // newpage.File.CheckIn("all looks good");
               // newpage.File.Publish("all looks good");

                PublishingWeb pubWeb = PublishingWeb.GetPublishingWeb(rootWeb);
                string newWelcomePageUrl = pubWeb.PagesList.Title + "/" + pageName;
                //Get the file name
                var serverRelativePageUrl = SPEncode.UrlDecodeAsUrl(string.Format("{0}/Pages/{1}",
                rootWeb.ServerRelativeUrl.Equals("/") ? string.Empty : rootWeb.ServerRelativeUrl, pageName));

                SPFile welcomeFile = rootWeb.GetFile(serverRelativePageUrl);


                //Assign the new filename to the DefaultPage property

                // rootWeb.RootFolder.WelcomePage = newWelcomePageUrl;
                pubWeb.DefaultPage = welcomeFile;
                //Update the Publishing Web.
                pubWeb.Update();
                rootWeb.Update();
            }

        }

        public static bool CreateDocLib(SPWeb web, string docLibName, string descp)
        {
            try
            {

                SPListTemplate listTemplate = web.ListTemplates["Document Library"];
                Guid guid = web.Lists.Add(docLibName, descp, listTemplate);

                SPDocumentLibrary library = web.Lists[guid] as SPDocumentLibrary;
                library.OnQuickLaunch = false;
                library.Update();
                return true;
            }
            catch (Exception ex)
            {
                return false;
              
            }

        }
        public static string UpLoadToDocLib(SPWeb web, string docLibName, string fileName, byte[] fileContent)
        {
            bool bAllowunsafeUpdate = web.AllowUnsafeUpdates;
            string url = null;
            try
            {
                web.AllowUnsafeUpdates = true;
                SPDocumentLibrary library = web.Lists[docLibName] as SPDocumentLibrary;
                if (library != null)
                {
                    SPFile file = library.RootFolder.Files.Add(fileName, fileContent, true);
                    url = library.RootFolder.ServerRelativeUrl + "/" + fileName;
                }
            }
            catch (Exception ex)
            {

            }
            finally
            {
                web.AllowUnsafeUpdates = bAllowunsafeUpdate;
            }

            return url;
        }

    }
}
