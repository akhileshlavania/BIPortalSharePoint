﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Animation;
using System.Windows.Shapes;
using System.Windows.Browser;

namespace RPX.SL
{
    public partial class MainPage : UserControl
    {
        public MainPage()
        {
            InitializeComponent();
            var targetUrl = GetQueryStringValueFromKey("targetUrl");
            App.LastVisitedURL = targetUrl;
            
            if (!string.IsNullOrEmpty(targetUrl))
            {
                wbUrlBrowser.Navigate(new Uri(targetUrl));
            }

            wbUrlBrowser.LoadCompleted += new System.Windows.Navigation.LoadCompletedEventHandler(wbUrlBrowser_LoadCompleted);

        }

        void wbUrlBrowser_LoadCompleted(object sender, System.Windows.Navigation.NavigationEventArgs e)
        {
            App.LastVisitedURL = e.Uri.AbsoluteUri;
        }

        private string GetQueryStringValueFromKey(string key)
        {
            IDictionary<string, string> qString = HtmlPage.Document.QueryString;
            foreach (KeyValuePair<string, string> keyValuePair in qString)
            {
                if (keyValuePair.Key == key)
                    return keyValuePair.Value;
            }

            return string.Empty;
        }
    }
}
