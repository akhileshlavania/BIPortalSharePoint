Write-Host "********************************************"
Write-Host "Adding solution...."
Write-Host "********************************************"
Add-SPSolution -LiteralPath C:\Deployment\2_Apr_14\WSP\RPXDev.wsp
Start-Sleep -s 10
Write-Host "********************************************"
Write-Host "Activating solution...."
Write-Host "********************************************"
Install-SPSolution -Identity RPXDev.wsp -WebApplication http://bipoc/ �GACDeployment
Start-Sleep -s 30
Write-Host "********************************************"
Write-Host "Activating feature...."
Write-Host "********************************************"
Enable-SPFeature -identity "96917ceb-adb5-473f-a039-119202280e37" -URL http://bipoc/ -Force